﻿namespace InventoryService.Model
{
    public class ProductQuantityUpdateModel
    {
        public int ProductId { get; set;}
        public int Quantity { get; set;}

    }
}
